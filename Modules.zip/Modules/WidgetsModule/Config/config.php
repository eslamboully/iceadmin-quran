<?php

return [
    'name' => 'WidgetsModule'
];
