<?php

return [
    'name' => 'PortfolioModule'
];
