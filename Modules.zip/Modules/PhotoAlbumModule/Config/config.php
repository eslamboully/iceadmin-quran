<?php

return [
    'name' => 'PhotoAlbumModule'
];
