<?php

return [
    'name' => 'ConfigModule'
];
