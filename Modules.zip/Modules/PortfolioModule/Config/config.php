<?php

return [
    'name' => 'PortfolioModule'
];
