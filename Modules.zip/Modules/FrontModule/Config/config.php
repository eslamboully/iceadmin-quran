<?php

return [
    'name' => 'FrontModule'
];
