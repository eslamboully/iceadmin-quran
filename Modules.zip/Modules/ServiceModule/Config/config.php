<?php

return [
    'name' => 'ServiceModule'
];
