<?php

return [
    'name' => 'PhotoAlbumModule'
];
