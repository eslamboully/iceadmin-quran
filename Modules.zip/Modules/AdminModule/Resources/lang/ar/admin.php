<?php

return array(
    'admins' => 'المديرين',
    #btn
    'add_new' => 'إضافة  جديد',
    'save'=>'حفظ',
    'cancel'=>'إلغاء',
    'edit'=>'تعديل',


    #form
    'email'=>'البريد الاكترونى',
    'name'=>'الاسم ',
    'op'=>'العمليات',
    'username'=>'اسم المستخدم',
    'password'=>'الرقم السرى' ,
    'acl' => 'الصلاحيات',
    'booking'=>'الحجز',
  'contact us'=>' اصل بنا',
  'product'=>'المنتجات',
  'products'=>'المنتجات',
  'product-categories'=>'اقسام  المنتجات',
  'category'=>'الاقسام',
  'project'=>'المشروعات',
 'projects'=>'المشروعات',
  'blogs'=>'المدونات',
  'blog-categories'=>' اقسام المدونه',
  'services'=>'الخدمات',
  'servicescategory'=>'اقسام الخدمات',
  'controll keybroad'=>'لوحه التحكم',
  'home'=>'الرئسيه',
  'pass_message'=>'اتركه فارغا ان لم ترد تغييره',
  
);
