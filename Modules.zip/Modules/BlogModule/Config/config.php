<?php

return [
    'name' => 'BlogModule'
];
