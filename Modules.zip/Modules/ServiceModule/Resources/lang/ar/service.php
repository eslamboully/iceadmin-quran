<?php

return array(

  # Service Category
  'categtitle' => ' أقسام الخدمات',
  'homepage' => 'الرئيسية',
  'addnew' => 'أضف جديد',
  'id' => 'الترتيب',
  'title' => 'العنوان',
  'category' => 'القسم',
  'photo'=>'الصوره',
  'edit'=>'تعديل',
  'delete'=>'مسح',
  'operation' => 'العمليات',
  'desc' => 'الوصف',
  'cancel' => 'الغاء',
  'submit' => 'حفظ',

  # Service
  'servicetitle' => 'الخدمات',
  'photo' => 'الصورة',
  'fill' => 'قم بملأ بعض الاقسام اولاً',
  'createnow' => 'املأ واحداً اﻵن!',
  'categ' => 'اختر القسم',
  'mt' => 'معلومات العنوان',
  'md' => 'معلومات الوصف',
  'tag' => 'ذات صلة',
  'is_featured' => 'خدمة مميزة',
  'feature' => 'مميزة',
   'not_feature'=>'غير مميزة',
   'yes'=>'نعم',
   'no'=>'لا',
   'cover_photo' => 'صورة الغلاف',

    #seo
    'md' => 'Meta Description',
    'mt' => 'Meta Title',
);
