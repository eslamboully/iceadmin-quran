<?php

return [
    'name' => 'AdminModule'
];
