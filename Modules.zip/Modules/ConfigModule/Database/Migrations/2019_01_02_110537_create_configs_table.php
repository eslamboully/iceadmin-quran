<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateConfigsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('configs', function (Blueprint $table) {
            $table->increments('id');
            $table->string('var');
            $table->integer('is_static')->default(0);
            $table->string('static_value')->nullable();
            $table->tinyInteger('type');
            $table->integer('category_id')->unsigned();

            $table->foreign('category_id')->references('id')->on('config_categories')->onDelete('cascade');
            $table->timestamps();
        });
    }

  
    public function down()
    {
        Schema::dropIfExists('configs');
    }
}
