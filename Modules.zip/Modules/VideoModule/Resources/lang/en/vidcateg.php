<?php

return array(
  'pagetitle'=> 'Video Categories',
  'homepage' => 'Home Page',
  'addnew' => 'Add New',
  'id' => 'ID',
  'title' => 'Title',
  'operation' => 'Operations',
  'submit' => 'Submit',
  'cancel' => 'Cancel',

  # Video
  'vidpage' => 'Video',
  'link' => 'Link',
  'categ' => 'Choose Category',
);