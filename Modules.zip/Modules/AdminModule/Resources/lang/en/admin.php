<?php

return array(
  'admins' => 'Admins',
  'pageTitle' => 'إضافة خبر جديد',

  #btn
  'add_new' => 'Add New',
  'cancel' => 'Cancel',
  'save' => 'Submit',
  'edit' => 'Edit',

    #form
  'email' => 'Email',
  'name' => 'Name',
  'op' => 'Operations',
  'username' => 'User Name',
  'password' => 'Password',
  'acl' => 'Permissions',
  'booking'=>'Booking',
  'contact us'=>'Contact us',
  'product'=>'Product',
  'products'=>'Products',
  'product-categories'=>'Product-categories',
  'category'=>'Category',
  'project'=>'Project',
 'projects'=>'Projects',
  'blogs'=>'Blogs',
  'blog-categories'=>'Blog-categories',
  'services'=>'Services',
  'servicescategory'=>'Servicescategory',
  'controll keybroad'=>'Controll keybroad',
  'home'=>'Home',
  'pass_message'=>'blank it if you dont change it',
  
);
