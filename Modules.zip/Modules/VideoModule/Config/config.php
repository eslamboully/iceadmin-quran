<?php

return [
    'name' => 'VideoModule'
];
