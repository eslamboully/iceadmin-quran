<?php

return [
    'name' => 'CommonModule'
];
