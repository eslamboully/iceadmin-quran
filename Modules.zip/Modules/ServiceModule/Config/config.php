<?php

return [
    'name' => 'ServiceModule'
];
