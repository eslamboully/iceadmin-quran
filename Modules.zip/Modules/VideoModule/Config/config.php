<?php

return [
    'name' => 'VideoModule'
];
