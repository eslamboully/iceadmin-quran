<?php

return array(
  # Portfolio
  'pagetitle' => 'Portfolio',
  'home' => 'Home Page',
  'fill' => 'Fill Some Categories First!',
  'fillnow' => 'Create now!',
  'title' => 'Title',
  'category' => 'Category',
  'desc' => 'Description',
  'photo' => 'Photo',
  'album' => 'Album',
  'categ' => 'Category',
  'mt' => 'Meta Title',
  'md' => 'Meta Desc',
  'tag' => 'Tags',
  'cancel' => 'Cancel',
  'submit' => 'Submit',
  'addnew' => 'Add New',
  'id' => 'ID',
  'title' => 'Title',
  'photo' => 'Photo',
  'operation' => 'Operations',
  'cover_photo' => 'cover photo',
  # Category
  'pagecategtitle' => 'Portfolio Category',
);
