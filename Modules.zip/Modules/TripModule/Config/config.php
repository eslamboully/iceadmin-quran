<?php

return [
    'name' => 'TripModule'
];
