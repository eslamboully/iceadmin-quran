<?php

return array(
  'pagetitle'=> 'Photo Categories',
  'homepage' => 'Home Page',
  'addnew' => 'Add New',
  'id' => 'ID',
  'title' => 'Title',
  'operation' => 'Operations',
  'submit' => 'Submit',
  'cancel' => 'Cancel',

  # photo
  'Photopage' => 'Photo',
  'photo' => 'Photo',
  'categ' => 'Choose Category',
);