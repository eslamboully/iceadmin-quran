<?php
/**
 * Created by PhpStorm.
 * User: aabed
 * Date: 1/20/19
 * Time: 3:24 PM
 */

return array(
    'settings' => 'الإعدادات',
    'update' => 'تحديث'
);
