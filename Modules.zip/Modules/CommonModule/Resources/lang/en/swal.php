<?php

return array (
  'good' => 'Good Job!',
  'saved' => 'Data Created Successfully!',
  'btn' => 'Ok',
  'edited' => 'Data Updated Successfully!',
    'send'=>'Message Sent Successfully!'
);
