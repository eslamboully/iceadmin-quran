<?php

return array(

  'pagetitle'=>'أقسام الصور',
  'homepage' => 'الرئيسية',
  'addnew' => 'أضف جديد',
  'id' => 'الترتيب',
  'title' => 'العنوان',
  'operation' => 'العمليات',
  'submit' => 'حفظ',
  'cancel' => 'إلغاء',
  
  # photo
  'Photopage' => 'الصور',
  'photo' => 'الصوره',
  'categ' => 'أختر القسم',
);