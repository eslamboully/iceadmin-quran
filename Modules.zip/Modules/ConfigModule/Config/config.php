<?php

return [
    'name' => 'ConfigModule'
];
