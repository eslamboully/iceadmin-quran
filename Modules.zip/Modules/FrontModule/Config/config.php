<?php

return [
    'name' => 'FrontModule'
];
