<?php

return [
    'name' => 'TripModule'
];
