<?php

return [
    'name' => 'BlogModule'
];
