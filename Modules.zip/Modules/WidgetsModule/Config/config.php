<?php

return [
    'name' => 'WidgetsModule'
];
