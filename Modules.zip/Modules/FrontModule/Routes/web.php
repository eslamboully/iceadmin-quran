<?php

Route::get('/', 'FrontModuleController@index');
