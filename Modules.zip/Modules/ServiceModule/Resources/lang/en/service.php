<?php

return array(

  # Service Category
  'categtitle' =>'Service Category',
  'homepage' => 'Home Page',
  'addnew' => 'Add New',
  'id' => 'ID',
  'title' => 'Title',
  'category' => 'Category',
  'photo'=>'Photo',
  'edit'=>'Edit',
   'delete'=>'Delete',
  'operation' => 'Operations',
  'desc' => 'Description',
  'cancel' => 'Cancel',
  'submit' => 'Submit',

  # Service
  'servicetitle' =>'Service',
  'photo' => 'Photo',
  'fill' => 'Fill some categories first!',
  'createnow' => 'Create One Now!',
  'categ' => 'Category',
  'mt' => 'Meta Title',
  'md' => 'Meta Description',
  'tag' => 'Tags',
  'is_featured' => 'Featured Service',
  'feature' => 'YES',
  'not_feature'=>'NO',
   'yes'=>'Yes',
   'no'=>'No',
   'cover_photo' => 'cover photo',
    'main_category' => 'parent category',


   #seo
   'md' => 'Meta Description',
   'mt' => 'Meta Title',
);
