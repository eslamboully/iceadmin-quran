<?php

return array(
  'pagetitle'=>'أقسام الفيديو',
  'homepage' => 'الرئيسية',
  'addnew' => 'أضف جديد',
  'id' => 'الترتيب',
  'title' => 'العنوان',
  'operation' => 'العمليات',
  'submit' => 'حفظ',
  'cancel' => 'إلغاء',
  
  # Video
  'vidpage' => 'الفيديو',
  'link' => 'الرابط',
  'categ' => 'أختر القسم',
);